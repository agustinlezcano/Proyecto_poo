#!/usr/bin/env python3
#encoding: UTF-8
import os
import glob
import time
import sys
sys.path.insert(0, 'home/agustin/Proyecto_poo/Proyecto_poo/POO')

def __init__(self):
    self.orden