#import Servidor.py as s

#class Servidor_XML_RPC(s.Servidor):

  #  def __init__(self):
